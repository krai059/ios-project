import SwiftUI

struct LoggedoutView: View {
    @StateObject var loggedoutViewModel = LoggedoutViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        ZStack(alignment: .center) {
            Image("img_rectangle")
                .resizable()
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(663.0),
                       alignment: .center)
                .scaledToFit()
                .clipped()
                .padding(.bottom, getRelativeHeight(105.0))
            VStack {
                Text("spacer")
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(343.0), height: getRelativeHeight(265.0))
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        ZStack(alignment: .center) {
                            Image("img_union_38x38")
                                .resizable()
                                .frame(width: getRelativeWidth(38.0),
                                       height: getRelativeWidth(38.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Image("img_union")
                                .resizable()
                                .frame(width: getRelativeWidth(38.0),
                                       height: getRelativeWidth(38.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(38.0), height: getRelativeWidth(38.0),
                               alignment: .top)
                        .padding(.vertical, getRelativeHeight(2.0))
                        Text(StringConstants.kLblPhoto)
                            .font(FontScheme.kComfortaaRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(148.0), height: getRelativeHeight(54.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(20.0))
                    }
                    .frame(width: getRelativeWidth(206.0), height: getRelativeHeight(54.0),
                           alignment: .center)
                    HStack {
                        Image("img_ellipse")
                            .resizable()
                            .frame(width: getRelativeWidth(28.0), height: getRelativeWidth(28.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipShape(Circle())
                            .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 0) {
                            Text(StringConstants.kMsgPawelCzerwinski)
                                .font(FontScheme.kRobotoBold(size: getRelativeHeight(13.0)))
                                .fontWeight(.bold)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(103.0),
                                       height: getRelativeHeight(16.0), alignment: .topLeading)
                            Text(StringConstants.kMsgPawelCzerwinski2)
                                .font(FontScheme.kRobotoRegular(size: getRelativeHeight(11.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900Cc)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(96.0),
                                       height: getRelativeHeight(13.0), alignment: .topLeading)
                        }
                        .frame(width: getRelativeWidth(103.0), height: getRelativeHeight(29.0),
                               alignment: .center)
                        .padding(.leading, getRelativeWidth(8.0))
                    }
                    .frame(width: getRelativeWidth(139.0), height: getRelativeHeight(29.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(294.0))
                }
                .frame(width: getRelativeWidth(343.0), height: getRelativeHeight(377.0),
                       alignment: .center)
                HStack {
                    Button(action: {}, label: {
                        HStack(spacing: 0) {
                            Text(StringConstants.kLblLogIn)
                                .font(FontScheme.kRobotoBlack(size: getRelativeHeight(13.0)))
                                .fontWeight(.black)
                                .padding(.horizontal, getRelativeWidth(30.0))
                                .padding(.vertical, getRelativeHeight(18.0))
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(167.0),
                                       height: getRelativeHeight(52.0), alignment: .center)
                                .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                        bottomLeft: 6.0,
                                                        bottomRight: 6.0)
                                        .stroke(ColorConstants.Black900,
                                                lineWidth: 2))
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(ColorConstants.WhiteA700))
                        }
                    })
                    .frame(width: getRelativeWidth(167.0), height: getRelativeHeight(52.0),
                           alignment: .center)
                    .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                            bottomRight: 6.0)
                            .stroke(ColorConstants.Black900,
                                    lineWidth: 2))
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(ColorConstants.WhiteA700))
                    ZStack(alignment: .center) {
                        Text(StringConstants.kLblRegister)
                            .font(FontScheme.kSFProTextBold(size: getRelativeHeight(13.0)))
                            .fontWeight(.bold)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(65.0), height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(33.58))
                            .padding(.horizontal, getRelativeWidth(51.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblRegister)
                                    .font(FontScheme.kRobotoBlack(size: getRelativeHeight(13.0)))
                                    .fontWeight(.black)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(167.0),
                                           height: getRelativeHeight(52.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                               bottomLeft: 6.0, bottomRight: 6.0)
                                            .fill(ColorConstants.Black900))
                            }
                        })
                        .frame(width: getRelativeWidth(167.0), height: getRelativeHeight(52.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.Black900))
                    }
                    .hideNavigationBar()
                    .frame(width: getRelativeWidth(167.0), height: getRelativeHeight(52.0),
                           alignment: .center)
                    .padding(.leading, getRelativeWidth(9.0))
                }
                .frame(width: getRelativeWidth(343.0), height: getRelativeHeight(52.0),
                       alignment: .center)
            }
            .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(735.0),
                   alignment: .center)
            .padding(.bottom, getRelativeHeight(33.0))
        }
        .hideNavigationBar()
        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(768.0))
    }
}

struct LoggedoutView_Previews: PreviewProvider {
    static var previews: some View {
        LoggedoutView()
    }
}
