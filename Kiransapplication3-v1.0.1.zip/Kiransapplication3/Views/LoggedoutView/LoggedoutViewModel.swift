import Foundation
import SwiftUI

class LoggedoutViewModel: ObservableObject {}
