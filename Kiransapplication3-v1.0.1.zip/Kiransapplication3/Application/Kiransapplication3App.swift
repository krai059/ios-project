//
//  Kiransapplication3App.swift
//  Kiransapplication3

import SwiftUI

@main
struct Kiransapplication3App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            LoggedoutView()
        }
    }
}
