import Foundation
import SwiftUI

class FontScheme: NSObject {
    static func kComfortaaRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kComfortaaRegular, size: size)
    }

    static func kRobotoBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoBold, size: size)
    }

    static func kRobotoRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoRegular, size: size)
    }

    static func kRobotoBlack(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoBlack, size: size)
    }

    static func kSFProTextBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kSFProTextBold, size: size)
    }

    static func fontFromConstant(fontName: String, size: CGFloat) -> Font {
        var result = Font.system(size: size)

        switch fontName {
        case "kComfortaaRegular":
            result = self.kComfortaaRegular(size: size)
        case "kRobotoBold":
            result = self.kRobotoBold(size: size)
        case "kRobotoRegular":
            result = self.kRobotoRegular(size: size)
        case "kRobotoBlack":
            result = self.kRobotoBlack(size: size)
        case "kSFProTextBold":
            result = self.kSFProTextBold(size: size)
        default:
            result = self.kComfortaaRegular(size: size)
        }
        return result
    }

    enum FontConstant {
        /**
         * Please Add this fonts Manually
         */
        static let kComfortaaRegular: String = "Comfortaa-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoBold: String = "Roboto-Bold"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoRegular: String = "RobotoRegular"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoBlack: String = "Roboto-Black"
        /**
         * Please Add this fonts Manually
         */
        static let kSFProTextBold: String = "SFProText-Bold"
    }
}
