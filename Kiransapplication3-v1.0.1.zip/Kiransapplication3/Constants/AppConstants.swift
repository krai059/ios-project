//
//  AppConstants.swift
//  Kiransapplication3

import Foundation

struct AppConstants {
    static let serverURL: String = "@{serverURL}"
}
