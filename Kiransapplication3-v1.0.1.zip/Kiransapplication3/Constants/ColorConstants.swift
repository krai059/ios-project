import SwiftUI

struct ColorConstants {
    static let Black900Cc: Color = .init("Black900Cc")
    static let Black900: Color = .init("Black900")
    static let WhiteA700: Color = .init("WhiteA700")
}
