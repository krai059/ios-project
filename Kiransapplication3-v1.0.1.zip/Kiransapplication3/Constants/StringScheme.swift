import UIKit

struct StringConstants {
    static let kMsgPawelCzerwinski: String = "Pawel Czerwinski"
    static let kMsgPawelCzerwinski2: String = "@pawel_czerwinski"
    static let k: String = ""
    static let kHttpFail: String = "HTTP request failed"
    static let kLblPhoto: String = "photo"
    static let kUnableToFetch: String = "Unable to fetch data"
    static let kLblRegister: String = "register"
    static let kInvalidUrl: String = "Invalid URL"
    static let kLblLogIn: String = "log in"
}
